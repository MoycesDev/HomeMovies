package com.example.homemovies.ui.watched

import android.arch.lifecycle.LiveData
import android.arch.lifecycle.MutableLiveData
import android.arch.lifecycle.ViewModel

class WatchedViewModel : ViewModel() {

    private val _text = MutableLiveData<String>().apply {
        value = "This is Watched Fragment"
    }
    val text: LiveData<String> = _text
}